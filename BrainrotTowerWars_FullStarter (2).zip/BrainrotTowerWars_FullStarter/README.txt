Brainrot Tower Wars - Starter Project
Files in Assets/ contain scripts and placeholders.
Import into Unity (2020+ recommended) or upload to Unity Cloud Build.
