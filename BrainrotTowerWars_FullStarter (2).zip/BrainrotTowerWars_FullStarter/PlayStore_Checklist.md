Play Store Upload Checklist - Brainrot Tower Wars

1. Create Google Play Developer account ($25)
2. Prepare app icon (512x512), feature graphic (1024x500), screenshots (at least 3-8).
3. Prepare a 15-30s promo video (vertical and landscape).
4. Build App Bundle (.aab) via Unity Cloud Build.
5. Prepare privacy policy URL and in-app purchase disclosures.
6. Ensure Unity IAP and Google Play Billing are integrated before release.
7. Upload internal test to Google Play Console, test on devices.
8. Fix crashes, polish, then move to Production release.
