using UnityEngine;

public class UpgradeSystem : MonoBehaviour
{
    public void UpgradeTower(Tower t)
    {
        if (t == null) return;
        CurrencyManager cm = FindObjectOfType<CurrencyManager>();
        int cost = 50;
        if (cm != null && cm.SpendBits(cost))
        {
            t.damage = Mathf.RoundToInt(t.damage * 1.5f);
            t.fireRate *= 1.2f;
        }
    }
}
