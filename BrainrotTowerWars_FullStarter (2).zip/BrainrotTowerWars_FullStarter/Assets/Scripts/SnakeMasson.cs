using UnityEngine;
using System.Collections;

public class SnakeMasson : Tower
{
    public GameObject blackHolePrefab;
    private bool canUse = true;
    private const string Key = "SnakeMasson_LastUse";

    void Start()
    {
        if (PlayerPrefs.HasKey(Key))
        {
            long last = long.Parse(PlayerPrefs.GetString(Key));
            long diff = System.DateTimeOffset.UtcNow.ToUnixTimeSeconds() - last;
            if (diff < 86400) StartCoroutine(Cooldown(86400 - diff));
        }
    }

    public void UseUltimate()
    {
        if (!canUse)
        {
            Debug.Log("SnakeMasson on cooldown");
            return;
        }
        StartCoroutine(BlackHoleSequence());
    }

    IEnumerator BlackHoleSequence()
    {
        canUse = false;
        // spawn black hole VFX
        if (blackHolePrefab != null) Instantiate(blackHolePrefab, transform.position, Quaternion.identity);

        // destroy all enemies
        Enemy[] all = FindObjectsOfType<Enemy>();
        foreach (var e in all) e.TakeDamage(999999);

        // skip levels: rudimentary - call StartNextWave multiple times
        for (int i=0;i<100;i++) GameManager.Instance?.StartNextWave();

        PlayerPrefs.SetString(Key, System.DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString());
        PlayerPrefs.Save();

        yield return StartCoroutine(Cooldown(86400));
    }

    IEnumerator Cooldown(long seconds)
    {
        yield return new WaitForSeconds(seconds);
        canUse = true;
        PlayerPrefs.DeleteKey(Key);
    }
}
