using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PackOpener : MonoBehaviour
{
    public GameObject[] towerPrefabs; // ordered by rarity: Common..Admin
    public Text resultText;
    public ParticleSystem commonFX;
    public ParticleSystem rareFX;

    public void OpenBasicPack()
    {
        StartCoroutine(OpenPackRoutine());
    }

    IEnumerator OpenPackRoutine()
    {
        int roll = Random.Range(0, 1000);
        int index = 0;
        if (roll < 700) index = 0; // common
        else if (roll < 900) index = 1; // uncommon
        else if (roll < 970) index = 2; // rare
        else if (roll < 995) index = 3; // legendary
        else index = 4; // mythic+

        // play some FX based on rarity
        if (index <= 1 && commonFX != null) commonFX.Play();
        else if (rareFX != null) rareFX.Play();

        yield return new WaitForSeconds(0.6f);

        GameObject chosen = towerPrefabs[Mathf.Min(index, towerPrefabs.Length-1)];
        Instantiate(chosen, Vector3.zero, Quaternion.identity);
        if (resultText != null) resultText.text = "You got: " + chosen.name;
    }
}
