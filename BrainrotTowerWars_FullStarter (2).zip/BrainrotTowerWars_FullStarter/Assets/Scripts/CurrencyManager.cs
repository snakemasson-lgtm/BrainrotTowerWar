using UnityEngine;
using UnityEngine.UI;

public class CurrencyManager : MonoBehaviour
{
    public int brainBits = 100;
    public Text brainBitsText;

    void Update()
    {
        if (brainBitsText != null) brainBitsText.text = "BrainBits: " + brainBits;
    }

    public void AddBits(int amount)
    {
        brainBits += amount;
    }

    public bool SpendBits(int amount)
    {
        if (brainBits >= amount)
        {
            brainBits -= amount;
            return true;
        }
        return false;
    }
}
