using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public Text waveText;
    private int waveNumber = 0;

    void Awake()
    {
        Instance = this;
    }

    public void StartNextWave()
    {
        waveNumber++;
        if (waveText != null) waveText.text = "Wave: " + waveNumber;
        EnemySpawner sp = FindObjectOfType<EnemySpawner>();
        if (sp != null) sp.StartNextWave();
    }

    public void AddCoins(int amount)
    {
        CurrencyManager cm = FindObjectOfType<CurrencyManager>();
        if (cm != null) cm.AddBits(amount);
    }
}
