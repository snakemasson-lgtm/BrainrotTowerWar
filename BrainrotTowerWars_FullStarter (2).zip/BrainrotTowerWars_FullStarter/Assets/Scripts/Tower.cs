using UnityEngine;
using System.Collections;

public class Tower : MonoBehaviour
{
    public string towerName = "Tower";
    public float range = 3f;
    public float fireRate = 1f;
    public int damage = 10;
    public GameObject projectilePrefab;
    public Transform firePoint;
    private float fireCountdown = 0f;

    void Update()
    {
        fireCountdown -= Time.deltaTime;
        if (fireCountdown <= 0f)
        {
            GameObject target = FindTarget();
            if (target != null)
            {
                Shoot(target.transform);
                fireCountdown = 1f / fireRate;
            }
        }
    }

    GameObject FindTarget()
    {
        Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, range);
        float closest = Mathf.Infinity;
        GameObject best = null;
        foreach (var hit in hits)
        {
            if (hit.gameObject.CompareTag("Enemy"))
            {
                float d = Vector3.Distance(transform.position, hit.transform.position);
                if (d < closest)
                {
                    closest = d;
                    best = hit.gameObject;
                }
            }
        }
        return best;
    }

    public virtual void Shoot(Transform target)
    {
        if (projectilePrefab != null && firePoint != null)
        {
            GameObject p = Instantiate(projectilePrefab, firePoint.position, Quaternion.identity);
            Projectile proj = p.GetComponent<Projectile>();
            if (proj != null) proj.SetTarget(target, damage);
        }
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, range);
    }
}
