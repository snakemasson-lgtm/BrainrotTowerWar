using UnityEngine;
using System.Collections;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemyPrefab;
    public Transform pathParent;
    public float timeBetweenWaves = 5f;
    private int waveNumber = 0;
    private bool spawning = false;

    public void StartNextWave()
    {
        if (!spawning) StartCoroutine(SpawnWave());
    }

    IEnumerator SpawnWave()
    {
        spawning = true;
        waveNumber++;
        int count = 5 + waveNumber * 2;
        for (int i = 0; i < count; i++)
        {
            GameObject e = Instantiate(enemyPrefab, pathParent.GetChild(0).position, Quaternion.identity);
            Enemy en = e.GetComponent<Enemy>();
            if (en != null)
            {
                Transform[] wp = new Transform[pathParent.childCount];
                for (int j=0;j<pathParent.childCount;j++) wp[j] = pathParent.GetChild(j);
                en.InitPath(wp);
            }
            yield return new WaitForSeconds(0.5f);
        }
        spawning = false;
    }
}
