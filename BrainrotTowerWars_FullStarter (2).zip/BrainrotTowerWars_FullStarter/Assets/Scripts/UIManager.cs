using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public Button nextWaveButton;
    public Button openPackButton;
    public Button useUltimateButton;
    public SnakeMasson snakeMasson;

    void Start()
    {
        if (nextWaveButton != null) nextWaveButton.onClick.AddListener(() => GameManager.Instance.StartNextWave());
        if (openPackButton != null) openPackButton.onClick.AddListener(() => FindObjectOfType<PackOpener>()?.OpenBasicPack());
        if (useUltimateButton != null && snakeMasson != null) useUltimateButton.onClick.AddListener(() => snakeMasson.UseUltimate());
    }
}
