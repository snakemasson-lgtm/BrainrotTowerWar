using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float speed = 2f;
    public int health = 50;
    public int reward = 5;
    private Transform[] path;
    private int waypointIndex = 0;

    public void InitPath(Transform[] wp)
    {
        path = wp;
        transform.position = path[0].position;
        waypointIndex = 0;
    }

    void Update()
    {
        if (path == null || waypointIndex >= path.Length) return;
        Transform target = path[waypointIndex];
        Vector3 dir = target.position - transform.position;
        transform.Translate(dir.normalized * speed * Time.deltaTime, Space.World);

        if (Vector3.Distance(transform.position, target.position) < 0.1f)
        {
            waypointIndex++;
            if (waypointIndex >= path.Length)
            {
                ReachGoal();
            }
        }
    }

    void ReachGoal()
    {
        // Damage player base or similar
        Destroy(gameObject);
    }

    public void TakeDamage(int amt)
    {
        health -= amt;
        if (health <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        GameManager gm = FindObjectOfType<GameManager>();
        if (gm != null) gm.AddCoins(reward);
        Destroy(gameObject);
    }
}
